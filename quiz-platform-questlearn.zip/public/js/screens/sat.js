/**
 * Path B: SAT Prep. Choose the timed Simulator or Topics Practice.
 */
import { h, mount, prefs } from '../ui.js';
import { loadSat, prepareQuestions } from '../data.js';
import { go } from '../router.js';
import { timedSeconds } from '../characters.js';
import { profile } from '../state.js';
import { chips, modeCard, topicGrid, selectAllButton } from './controls.js';

const FORMATS = [
  { id: 'full', label: 'Full test', sections: ['rw', 'math'], text: 'Reading & Writing, a short break, then Math.' },
  { id: 'rw', label: 'Reading & Writing', sections: ['rw'], text: 'One timed Reading & Writing section.' },
  { id: 'math', label: 'Math', sections: ['math'], text: 'One timed Math section.' },
];

export function renderSat(app) {
  const sel = { mode: 'sim', format: 'full', count: 10, ...prefs.get('sat', {}), topics: new Set() };
  let bank = null;

  mount(app, h('section.loading', {}, 'Loading SAT bank…'));
  loadSat().then((data) => { bank = data; draw(); }).catch((err) => mount(app, h('section.panel.error', {}, err.message)));

  function update(patch) {
    Object.assign(sel, patch);
    prefs.set('sat', { mode: sel.mode, format: sel.format, count: sel.count });
    draw();
  }

  /** Topics of one section, keyed for stats and with a question count for the picker. */
  const sectionTopics = (section) => bank.topics
    .filter((t) => t.section === section)
    .map((t) => ({ ...t, key: `sat:${t.id}`, count: t.questions.length }));
  const sectionSeconds = (section) => timedSeconds(
    sectionTopics(section).reduce((n, t) => n + t.count, 0), bank.sections[section].secondsPerQuestion, profile.character);

  function draw() {
    const simPanel = h('div.panel.sat-panel', {},
      h('h3', {}, 'Simulator format'),
      h('div.format-grid', {}, FORMATS.map((f) =>
        h('button.format-card', { type: 'button', 'aria-pressed': String(sel.format === f.id), onclick: () => update({ format: f.id }) },
          h('b', {}, f.label),
          h('p', {}, f.text),
          h('span.format-meta', {}, f.sections.map((s) =>
            `${sectionTopics(s).reduce((n, t) => n + t.count, 0)} Q · ${Math.round(sectionSeconds(s) / 60)} min`).join('  +  '))))),
      h('ul.rules', {},
        h('li', {}, 'Each section has its own clock, paced like the digital SAT.'),
        h('li', {}, 'Move freely inside a section, mark questions for review, then submit.'),
        h('li', {}, 'No feedback until the end. You get a scaled score from 200–800 per section.')),
      h('button.btn.primary.lg', { onclick: startSim }, 'Start simulator'));

    const allTopics = [...sectionTopics('math'), ...sectionTopics('rw')];
    const topicPanel = h('div.panel.sat-panel', {},
      h('div.course-head', {}, h('h3', {}, 'Pick topics'), selectAllButton(allTopics, sel.topics, draw)),
      ['math', 'rw'].map((section) => h('div.sat-group', {},
        h('p.eyebrow', {}, bank.sections[section].name),
        topicGrid(sectionTopics(section), sel.topics, draw, () => (section === 'math' ? '∑' : '¶')))),
      h('div.start-row', {},
        chips('Questions', [5, 10, 20].map((n) => ({ value: n, label: String(n) })), sel.count, (count) => update({ count })),
        h('button.btn.primary.lg', { disabled: sel.topics.size === 0, onclick: startTopics },
          sel.topics.size ? 'Start practice' : 'Pick at least one topic')));

    mount(app,
      h('section', {},
        h('div.crumbs', {}, h('button.link', { onclick: () => go('hub') }, '← Hub'), h('span', {}, 'SAT Preparation')),
        h('h1.display', {}, 'SAT Preparation'),
        h('div.mode-grid', {},
          modeCard({
            icon: '🏛️', title: 'SAT Simulator', pressed: sel.mode === 'sim', onclick: () => update({ mode: 'sim' }),
            text: 'Timed section exams in realistic test conditions, with scaled scoring.',
          }),
          modeCard({
            icon: '🧩', title: 'Topics Practice', pressed: sel.mode === 'topics', onclick: () => update({ mode: 'topics' }),
            text: 'Drill one SAT skill at a time with hints, skills and explanations.',
          })),
        sel.mode === 'sim' ? simPanel : topicPanel));
  }

  function startSim() {
    const format = FORMATS.find((f) => f.id === sel.format);
    const sections = format.sections.map((id) => ({
      name: bank.sections[id].name,
      questions: prepareQuestions(sectionTopics(id)),
      timeLimit: sectionSeconds(id),
    }));
    go('simulator', { title: `SAT Simulator · ${format.label}`, origin: 'sat', sections, restart: startSim });
  }

  function startTopics() {
    const topics = [...sectionTopics('math'), ...sectionTopics('rw')].filter((t) => sel.topics.has(t.id));
    go('play', {
      mode: 'practice',
      origin: 'sat',
      title: topics.length === 1 ? topics[0].name : `SAT · ${topics.length} topics`,
      subtitle: 'SAT Topics Practice',
      questions: prepareQuestions(topics, { limit: sel.count }),
      timeLimit: null,
      restart: startTopics,
    });
  }
}
